assert = chai.assert;
num = 100
const url = "http://localhost:3000/post"


describe("Testing the servers sharing functionality", () => {
    it('Making a thousand users', () =>{
        completed = true
        var i=0
        while(i<num && completed){
            $.post(
                url+'?data='+JSON.stringify({
                    'action' : 'createaccount',
                    'password' : i,
                    'username' : i,
                }), response
            );
            
            i++
        }
        function response(data,status){
            var response = JSON.parse(data)
            console.log(data)
            if(response['action']=='usercheck'){
                
                completed = true
            }
            else{
                completed = false
            }
        }
        assert.equal(completed,true)
    })
    it("sharing the diary as admin to all thousand users", () =>{
        var i =0
        callback = true
        function response(data,status){
            var response = JSON.parse(data)
            console.log(data)
        if((response['action']=='shared?')){
            callback = true
            }
            else{
                callback = false
            }
        }
        while(i<num && callback){
            $.post(url+"?data="+JSON.stringify({
            'action' : 'usershare',
            'username' : "Admin",
            'shareuser' : i,
            'diarytitle' : "Admins Diary"
            }),response
            )
            i++
        }
        assert.equal(callback,true)
    })
    it("Checking if the shared users have access to the diary", () =>{
        var i = 0
        hasdiary = true
        function response(data, status){
            var response = JSON.parse(data)
            console.log("Recieved data " + data)
            if(response['action']=='titlereturn'){
                if(!(response['titlelist'].includes("Admins Diary"))){
                    hasdiary = false
                }
            }
        }
        while(i<num && hasdiary){
            $.post(
                url+'?data='+JSON.stringify({
                    'action' : 'titlerequest',
                    'username' : i
                }), response
            );
            i++
        }
        assert.equal(hasdiary,true)
    })
    it("Checking if the diaries contents is the same", () => {
        function response(data, status){
            var response = JSON.parse(data)
            console.log(data)
            if(response['action']=='diaryreturn'){
                if(!(response['diarydata']=='<hr> Hello there </hr>')){
                    issame = false
                }

            }
        }
        var issame = true
        var i = 0
        while(i<num && issame){
            $.post(
                url+'?data='+JSON.stringify({
                    'action' : 'diaryfetch',
                    'diarytitle' : "Admins Diary",
                    'username' : i
                }), response
            )
            i++
        }
        assert.equal(issame,true)
    })
})